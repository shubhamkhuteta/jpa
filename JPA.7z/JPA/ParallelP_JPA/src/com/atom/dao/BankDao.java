package com.atom.dao;


import javax.persistence.EntityManager;
import com.atom.entities.BankEntity;


public class BankDao implements BankDaoI {

	EntityManager em;
	ConnectionDatabase cd=new ConnectionDatabase();
	
	@Override
	public long getBalance(long accNo) {
		
		em = cd.getConnection();
		em.getTransaction().begin();
		BankEntity emp1=(BankEntity) em.find(BankEntity.class,new Long(accNo));
		em.getTransaction().commit();
		return emp1.getBalance();
		

	}

	@Override
	public void setBalance(long accNo, long bal, String st){
		em = cd.getConnection();
		em.getTransaction().begin();
		BankEntity emp1=(BankEntity) em.find(BankEntity.class,new Long(accNo));
		
		
	
		String str = emp1.getTran() + st;
		emp1.setTran(str);
		emp1.setBalance(bal);
		em.merge(emp1);
				em.getTransaction().commit();
	}

	
	@Override
	public boolean checkPassword(String str,long accNo)  {
		em = cd.getConnection();
		em.getTransaction().begin();
		BankEntity be=(BankEntity) em.find(BankEntity.class,new Long(accNo));
		if (be.getPassword().equals(str))
			return true;
		else
			return false;

	}

	@Override
	public boolean checkAccNo(long accNo){
		em = cd.getConnection();
		em.getTransaction().begin();
		BankEntity emp1=(BankEntity) em.find(BankEntity.class,new Long(accNo));
		
		if (emp1==null)
			return false;
		else
			return true;

	}

	@Override
	public long setData(BankEntity bb) {
	
		em = cd.getConnection();
		em.getTransaction().begin();
		em.persist(bb);
		em.getTransaction().commit();
		return bb.getAccNo();
	}

	@Override
	public String getTransaction(long accNo) {
		// TODO Auto-generated method stub
		em = cd.getConnection();
		em.getTransaction().begin();
		BankEntity emp1=(BankEntity) em.find(BankEntity.class,new Long(accNo));
		em.getTransaction().commit();
		return emp1.getTran();
	}

	public BankEntity getInfo(long accNo) {
		// TODO Auto-generated method stub
		em = cd.getConnection();
		em.getTransaction().begin();
		BankEntity emp1=(BankEntity) em.find(BankEntity.class,new Long(accNo));
		em.getTransaction().commit();
		return emp1;
	}

	
}
